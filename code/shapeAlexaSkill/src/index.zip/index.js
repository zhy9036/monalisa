var distances = {
  "a lot" : 15,
  "a little" : 5,
  "normal" : 10
};

var currentWindow = {x: 25, y:50, width: 20, height: 20};

// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.
exports.handler = function (event, context) {
    try {
        console.log("event.session.application.applicationId=" + event.session.application.applicationId);

        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */

        // if (event.session.application.applicationId !== "") {
        //     context.fail("Invalid Application ID");
        //  }

        if (event.session.new) {
            onSessionStarted({requestId: event.request.requestId}, event.session);
        }

        if (event.request.type === "LaunchRequest") {
            onLaunch(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "IntentRequest") {
            onIntent(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "SessionEndedRequest") {
            onSessionEnded(event.request, event.session);
            context.succeed();
        }
    } catch (e) {
        context.fail("Exception: " + e);
    }
};

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    // add any session init logic here
}

/**
 * Called when the user invokes the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback) {

}

/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(intentRequest, session, callback) {

    var intent = intentRequest.intent;
    var intentName = intentRequest.intent.name;

    if (intentName == "makeWindowIntent") {
        handleMakeWindowResponse(intent, session, callback);
    }
    else if (intentName == "moveAlotIntent") {
        handleMoveAlotResponse(intent, session, callback);
    }
    else if (intentName == "moveIntent") {
        //do something
    }
    else {
        throw "invalid Intent";
    }
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {

}

// ------- Skill specific logic -------

function getWelcomeResponse(callback) {
    var output = "Welcome to Shape Wall!";


    var shouldEndSession = false;

    var sessionAttributes = {
        "speechOutput" : output
    }
    callback(sessionAttributes, buildSpeechletResponseWithoutCard(output,  output, shouldEndSession));
}

function handleMoveAlotResponse(intent, session, callback) {
    var direction = intent.slots.direction.value.toLowerCase();
    moveUtility(15, direction);
}

function handleMoveAlittletResponse(intent, session, callback) {
    var direction = intent.slots.direction.value.toLowerCase();
    moveUtility(5, direction);
}

function handleMoveResponse(intent, session, callback) {
    var direction = intent.slots.direction.value.toLowerCase();
    if (moveUtility(10, direction)) {
        var speechOutput = "Success! Wall Moved!";
    }
    else {
        var speechOutput = "Fail!";
    }
    var reprompt = "To move again, Say a command.";

    callback(session.attributes, buildSpeechletResponseWithoutCard(speechOutput, reprompt, false));
}

function handleMakeWindowResponse(intent, session, callback) {

}

function moveUtility (distance, direction) {
    var success = true;


    if (direction == "left") {
        currentWindow.x -= distance;
    }
    else if (direction == "right") {
        currentWindow.x += distance;
    }
    else if (direction == "up") {
        currentWindow.y -= distance;

    }
    else if (direction == "down") {
        currentWindow.y += distance;
    }
    var xmlString = "<xml><x>" + currentWindow.x.toString() + "</x>" +
        "<y>" + currentWindow.y.toString() + "</y>" +
        "<width>" + currentWindow.width + "</width>" +
        "<height>" + currentWindow.height + "</height></xml>";

    try {
        var http = require('http'),
            options = {method: 'HEAD', host: 'shapetest.loganstrong.com', port: 80, path: '/recieveDate.php?value=' + xmlString},
            req = http.request(options, function(r) {
                console.log(JSON.stringify(r.headers));
            });
        req.end();
    }
    catch (e){
        success = false;
    }



    return success;
}


function handleGetHelpRequest(intent, session, callback) {
    // Ensure that session.attributes has been initialized
    if (!session.attributes) {
        session.attributes = {};

    }

    function handleFinishSessionRequest(intent, session, callback) {
        // End the session with a "Good bye!" if the user wants to quit the game
        callback(session.attributes,
            buildSpeechletResponseWithoutCard("Good bye!", "", true));
    }


// ------- Helper functions to build responses for Alexa -------


    function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
        return {
            outputSpeech: {
                type: "PlainText",
                text: output
            },
            card: {
                type: "Simple",
                title: title,
                content: output
            },
            reprompt: {
                outputSpeech: {
                    type: "PlainText",
                    text: repromptText
                }
            },
            shouldEndSession: shouldEndSession
        };
    }

    function buildSpeechletResponseWithoutCard(output, repromptText, shouldEndSession) {
        return {
            outputSpeech: {
                type: "PlainText",
                text: output
            },
            reprompt: {
                outputSpeech: {
                    type: "PlainText",
                    text: repromptText
                }
            },
            shouldEndSession: shouldEndSession
        };
    }

    function buildResponse(sessionAttributes, speechletResponse) {
        return {
            version: "1.0",
            sessionAttributes: sessionAttributes,
            response: speechletResponse
        };
    }
}